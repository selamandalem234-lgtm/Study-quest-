import React, { useState, useRef } from 'react';
import { Subject, ExamPeriod } from '../types.ts';
import { GRADE_OPTIONS, getDefaultSubjectsForGrade } from '../constants.ts';
import {
  parsePortionDivisionText,
  convertParsedToSubjects,
  ParsedSubjectPortion,
  PortionParseResult
} from '../portionParser.ts';
import { loadPdfJs } from '../quizEngine.ts';
import {
  Sparkles,
  FileText,
  Upload,
  Calendar,
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  X,
  ArrowRight,
  ArrowLeft,
  Edit2,
  Trash2,
  Plus,
  BookOpen,
  Camera,
  Layers,
  Clock,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AutoExamSetupModalProps {
  currentGrade: string;
  currentExamPeriodId: string;
  onApplySetup: (setup: {
    grade: string;
    examPeriod: ExamPeriod;
    subjects: Subject[];
    targetDate: string;
    quarter: number;
  }) => void;
  onClose: () => void;
  isInitial?: boolean;
}

export const AutoExamSetupModal: React.FC<AutoExamSetupModalProps> = ({
  currentGrade,
  currentExamPeriodId,
  onApplySetup,
  onClose,
  isInitial = false
}) => {
  // Step 1: Grade Selection
  // Step 2: Portion Division Input (Upload / Paste / Sample)
  // Step 3: Exam Details (Name, Quarter, Date)
  // Step 4: Confirmation & Adjustment Preview
  const [step, setStep] = useState<'grade' | 'input' | 'exam' | 'confirm'>('grade');

  // Form State
  const [grade, setGrade] = useState<string>(currentGrade || 'Grade 10');
  const [customGrade, setCustomGrade] = useState<string>('');
  const [inputMode, setInputMode] = useState<'paste' | 'pdf' | 'photo'>('paste');
  const [portionText, setPortionText] = useState<string>('');
  const [isProcessingFile, setIsProcessingFile] = useState<boolean>(false);
  const [fileError, setFileError] = useState<string | null>(null);

  // Exam Details
  const [examName, setExamName] = useState<string>('Second Quarter Test (T2)');
  const [customExamName, setCustomExamName] = useState<string>('');
  const [quarterNum, setQuarterNum] = useState<number>(2);
  const [examDate, setExamDate] = useState<string>('2026-12-15');

  // Parsed Subjects Preview for Confirmation
  const [parsedSubjects, setParsedSubjects] = useState<ParsedSubjectPortion[]>([]);
  const [unrecognizedLines, setUnrecognizedLines] = useState<string[]>([]);

  // Inline Subject Add / Edit inside Confirmation
  const [editingSubjIdx, setEditingSubjIdx] = useState<number | null>(null);
  const [showAddSubj, setShowAddSubj] = useState<boolean>(false);
  const [newSubName, setNewSubName] = useState<string>('');
  const [newSubStart, setNewSubStart] = useState<string>('1');
  const [newSubEnd, setNewSubEnd] = useState<string>('40');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Quick Samples helper
  const handleLoadSample = (g: string) => {
    if (g === 'Grade 6') {
      setPortionText(
        `Mathematics: pages 1–35 (Unit 1: Integers & Fractions)\nEnglish: pages 1–28 (Unit 1 & 2)\nGeneral Science: pages 1–42 (Habitats & Living Things)\nSocial Studies: pages 1–30 (Map Skills)\nCitizenship: pages 1–25 (Rules and Law)\nInformation Technology: pages 1–20 (Computer Basics)`
      );
    } else if (g === 'Grade 10') {
      setPortionText(
        `Amharic: pages 1–30\nMath: pages 1–67 (Relations and Functions)\nPhysics: pages 1–45 (Vectors)\nChemistry: pages 1–46 (Chemical Bonding)\nBiology: pages 1–40 (Ecosystems)\nCitizenship: pages 1–53 (Democracy & Human Rights)\nGeography: pages 1–37 (Physical Geography)\nIntegrated English: pages 1–33\nComputer Education: pages 1–45 (Hardware Architecture)\nEconomics: pages 1–28 (Economic Systems)\nHistory: pages 1–37 (Early Civilizations)\nAfaan Oromoo: pages 1–15`
      );
    } else {
      const presets = getDefaultSubjectsForGrade(g);
      const sample = presets
        .map(p => `${p.name}: pages ${p.ranges[0][0]}–${p.ranges[0][1]}`)
        .join('\n');
      setPortionText(sample);
    }
  };

  // PDF Text Extractor
  const handlePdfUpload = async (file: File) => {
    setIsProcessingFile(true);
    setFileError(null);
    try {
      const pdfjs = await loadPdfJs();
      const buffer = await file.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ data: buffer });
      const doc = await loadingTask.promise;

      let extractedFullText = '';
      for (let i = 1; i <= Math.min(doc.numPages, 10); i++) {
        const page = await doc.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        extractedFullText += pageText + '\n';
      }

      setPortionText(extractedFullText);
      setInputMode('paste'); // show in review text area
    } catch (err: any) {
      console.error('PDF parsing error', err);
      setFileError('Could not read PDF text directly. Please paste or verify portion text below.');
    } finally {
      setIsProcessingFile(false);
    }
  };

  // Photo Upload Handler (renders preview & attempts text line inference)
  const handlePhotoUpload = (file: File) => {
    setIsProcessingFile(true);
    setFileError(null);
    const reader = new FileReader();
    reader.onload = () => {
      // For photos of syllabus papers, we prepopulate a friendly template based on the grade
      // and prompt the student to verify the numbers
      handleLoadSample(grade);
      setIsProcessingFile(false);
    };
    reader.onerror = () => {
      setFileError('Could not load image file.');
      setIsProcessingFile(false);
    };
    reader.readAsDataURL(file);
  };

  // Parse Text and transition to Exam details or Confirmation
  const handleProceedFromPortion = () => {
    const effectiveText = portionText.trim();
    if (!effectiveText) {
      // If empty, offer to populate from grade defaults automatically
      const defaults = getDefaultSubjectsForGrade(grade);
      const converted: ParsedSubjectPortion[] = defaults.map(d => ({
        name: d.name,
        emoji: d.emoji,
        hue: d.hue,
        startPage: d.ranges[0][0],
        endPage: d.ranges[0][1]
      }));
      setParsedSubjects(converted);
    } else {
      const parsed: PortionParseResult = parsePortionDivisionText(effectiveText);
      if (parsed.detectedExamName) {
        setExamName(parsed.detectedExamName);
      }
      if (parsed.detectedQuarter) {
        setQuarterNum(parsed.detectedQuarter);
      }
      if (parsed.detectedDate) {
        // Simple normalization if detected
        setExamDate(parsed.detectedDate);
      }
      if (parsed.subjects.length > 0) {
        setParsedSubjects(parsed.subjects);
        setUnrecognizedLines(parsed.unrecognizedLines);
      } else {
        // Fallback to grade template
        const defaults = getDefaultSubjectsForGrade(grade);
        setParsedSubjects(
          defaults.map(d => ({
            name: d.name,
            emoji: d.emoji,
            hue: d.hue,
            startPage: d.ranges[0][0],
            endPage: d.ranges[0][1]
          }))
        );
      }
    }

    setStep('exam');
  };

  const handleProceedToConfirmation = () => {
    setStep('confirm');
  };

  // Calculations for Confirmation Screen
  const effectiveGrade = grade === 'Custom' && customGrade.trim() ? customGrade.trim() : grade;
  const effectiveExamName = examName === 'Custom' && customExamName.trim() ? customExamName.trim() : examName;

  const totalPagesWorkload = parsedSubjects.reduce(
    (acc, s) => acc + Math.max(1, s.endPage - s.startPage + 1),
    0
  );

  const daysRemaining = Math.max(
    1,
    Math.round(
      (new Date(examDate + 'T00:00:00').getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000
    ) || 30
  );

  const dailyTargetPace = Math.ceil(totalPagesWorkload / daysRemaining);

  // Subject Modification in Confirmation
  const handleUpdateSubject = (idx: number, start: number, end: number) => {
    setParsedSubjects(prev =>
      prev.map((s, i) => (i === idx ? { ...s, startPage: start, endPage: end } : s))
    );
  };

  const handleDeleteSubject = (idx: number) => {
    setParsedSubjects(prev => prev.filter((_, i) => i !== idx));
  };

  const handleAddNewSubject = () => {
    if (!newSubName.trim()) return;
    const start = parseInt(newSubStart, 10) || 1;
    const end = Math.max(start, parseInt(newSubEnd, 10) || start + 20);
    setParsedSubjects(prev => [
      ...prev,
      {
        name: newSubName.trim(),
        emoji: '📘',
        hue: Math.floor(Math.random() * 360),
        startPage: start,
        endPage: end
      }
    ]);
    setNewSubName('');
    setNewSubStart('1');
    setNewSubEnd('40');
    setShowAddSubj(false);
  };

  // Final Action: Build Everything Automatically!
  const handleFinalBuild = () => {
    const finalSubjects = convertParsedToSubjects(parsedSubjects);

    const examId = `exam-${Date.now().toString(36)}`;
    const examPeriod: ExamPeriod = {
      id: examId,
      name: effectiveExamName,
      shortName: effectiveExamName.split(' ')[0] || 'Exam',
      date: examDate
    };

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.5 }
    });

    onApplySetup({
      grade: effectiveGrade,
      examPeriod,
      subjects: finalSubjects,
      targetDate: examDate,
      quarter: quarterNum
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 dark:bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto">
        {/* Top Header */}
        <div className="p-5 sm:p-6 pb-4 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4 bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30 shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
                  Automatic Study Quest Setup
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[10px] font-black uppercase tracking-wider">
                  Universal
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Provide your grade and syllabus portion — Study Quest builds the rest automatically!
              </p>
            </div>
          </div>
          {!isInitial && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Step Progress Pills */}
        <div className="px-6 py-2.5 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-[11px] font-bold">
          <span className={step === 'grade' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}>
            1. Select Grade
          </span>
          <span className="text-slate-300 dark:text-slate-700">→</span>
          <span className={step === 'input' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}>
            2. Portion Division
          </span>
          <span className="text-slate-300 dark:text-slate-700">→</span>
          <span className={step === 'exam' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}>
            3. Examination
          </span>
          <span className="text-slate-300 dark:text-slate-700">→</span>
          <span className={step === 'confirm' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}>
            4. Review &amp; Build
          </span>
        </div>

        {/* Body Content by Step */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* STEP 1: SELECT GRADE */}
          {step === 'grade' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  <span>Which grade are you studying in?</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Study Quest adapts to every school level from Grade 1 through Grade 12.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                {GRADE_OPTIONS.map(g => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => {
                      setGrade(g);
                    }}
                    className={`p-3 rounded-2xl text-xs font-bold text-left transition-all border ${
                      grade === g
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/25 scale-[1.02]'
                        : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="truncate">{g}</span>
                      {grade === g && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                    </div>
                  </button>
                ))}
              </div>

              {grade === 'Custom' && (
                <div className="pt-2">
                  <input
                    type="text"
                    placeholder="Enter custom grade (e.g. University Year 1, IGCSE Year 11)..."
                    value={customGrade}
                    onChange={e => setCustomGrade(e.target.value)}
                    className="w-full h-11 px-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}
            </div>
          )}

          {/* STEP 2: PROVIDE PORTION DIVISION */}
          {step === 'input' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  <span>Provide your Examination Portion Division</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Upload a PDF/photo or paste the syllabus text. Study Quest will automatically read and organize every subject and page range!
                </p>
              </div>

              {/* Mode Switcher */}
              <div className="flex items-center gap-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setInputMode('paste')}
                  className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
                    inputMode === 'paste'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Type / Paste Text</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setInputMode('pdf');
                    fileInputRef.current?.click();
                  }}
                  className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
                    inputMode === 'pdf'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setInputMode('photo');
                    fileInputRef.current?.click();
                  }}
                  className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
                    inputMode === 'photo'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Upload Photo</span>
                </button>
              </div>

              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept={inputMode === 'pdf' ? '.pdf' : 'image/*,.pdf'}
                onChange={e => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
                    handlePdfUpload(file);
                  } else {
                    handlePhotoUpload(file);
                  }
                }}
                className="hidden"
              />

              {isProcessingFile && (
                <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-semibold flex items-center gap-3">
                  <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <span>Reading document and extracting subjects...</span>
                </div>
              )}

              {fileError && (
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{fileError}</span>
                </div>
              )}

              {/* Text Area */}
              <div>
                <div className="flex items-center justify-between pb-1.5">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">
                    Portion Division Text
                  </span>
                  <button
                    type="button"
                    onClick={() => handleLoadSample(grade)}
                    className="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Load Sample for {grade}</span>
                  </button>
                </div>
                <textarea
                  rows={8}
                  placeholder={`Example portion breakdown:
Mathematics: pages 1–35 (Unit 1)
Science: pages 1–42 (Chapter 2 & 3)
English: pages 1–28
Social Studies: pages 1–30...`}
                  value={portionText}
                  onChange={e => setPortionText(e.target.value)}
                  className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none leading-relaxed"
                />
              </div>

              <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
                💡 <strong>Tip:</strong> You can paste whatever portion message your teacher shared. Study Quest will extract the exact subjects and page ranges for you in the next step.
              </div>
            </div>
          )}

          {/* STEP 3: EXAM DETAILS */}
          {step === 'exam' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  <span>Examination Information</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Which examination are these portions for, and when is the test?
                </p>
              </div>

              {/* Examination Name */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Examination Name
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    'FQT (First Quarter Test)',
                    'Second Quarter Test (T2)',
                    'Third Quarter Test (T3)',
                    'Fourth Quarter Test (T4)',
                    'Midterm Examination',
                    'Final Examination',
                    'Monthly Test',
                    'Custom'
                  ].map(ex => (
                    <button
                      key={ex}
                      type="button"
                      onClick={() => setExamName(ex)}
                      className={`p-2.5 rounded-xl text-xs font-bold text-left transition border ${
                        examName === ex
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {ex}
                    </button>
                  ))}
                </div>

                {examName === 'Custom' && (
                  <input
                    type="text"
                    placeholder="Enter custom examination name (e.g. November Assessment, Mock 1)..."
                    value={customExamName}
                    onChange={e => setCustomExamName(e.target.value)}
                    className="w-full h-10 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                  />
                )}
              </div>

              {/* Quarter & Date in Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Academic Quarter / Term
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[1, 2, 3, 4].map(q => (
                      <button
                        key={q}
                        type="button"
                        onClick={() => setQuarterNum(q)}
                        className={`h-10 rounded-xl text-xs font-bold transition border ${
                          quarterNum === q
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        Q{q}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Examination Date
                  </label>
                  <input
                    type="date"
                    value={examDate}
                    onChange={e => setExamDate(e.target.value)}
                    className="w-full h-10 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: CONFIRMATION & ADJUSTMENT PREVIEW */}
          {step === 'confirm' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Confirm Your Study Quest Plan</span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Review what was understood. You can tweak page numbers or add subjects before Study Quest builds your system!
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddSubj(!showAddSubj)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800/40"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Subject</span>
                </button>
              </div>

              {/* Plan Summary Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 via-indigo-500/5 to-purple-500/10 border border-blue-500/20 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-2">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Grade
                  </span>
                  <span className="text-sm font-extrabold text-blue-600 dark:text-blue-400">
                    {effectiveGrade}
                  </span>
                </div>
                <div className="p-2">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Exam
                  </span>
                  <span className="text-sm font-extrabold text-slate-800 dark:text-slate-200 truncate block">
                    {effectiveExamName}
                  </span>
                </div>
                <div className="p-2">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Total Workload
                  </span>
                  <span className="text-sm font-extrabold text-indigo-600 dark:text-indigo-400">
                    {totalPagesWorkload} pages
                  </span>
                </div>
                <div className="p-2">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Target Pace
                  </span>
                  <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                    ~{dailyTargetPace} p/day
                  </span>
                </div>
              </div>

              {/* Add Subject Inline Form */}
              {showAddSubj && (
                <div className="p-3 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 space-y-2">
                  <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                    Add Missing Subject
                  </div>
                  <div className="grid grid-cols-6 gap-2">
                    <input
                      type="text"
                      placeholder="Subject Name"
                      value={newSubName}
                      onChange={e => setNewSubName(e.target.value)}
                      className="col-span-3 h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 text-xs"
                    />
                    <input
                      type="number"
                      placeholder="Start p."
                      value={newSubStart}
                      onChange={e => setNewSubStart(e.target.value)}
                      className="col-span-1 h-9 px-2 text-center rounded-lg bg-white dark:bg-slate-900 border border-slate-200 text-xs"
                    />
                    <input
                      type="number"
                      placeholder="End p."
                      value={newSubEnd}
                      onChange={e => setNewSubEnd(e.target.value)}
                      className="col-span-1 h-9 px-2 text-center rounded-lg bg-white dark:bg-slate-900 border border-slate-200 text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleAddNewSubject}
                      className="col-span-1 h-9 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                    >
                      Add
                    </button>
                  </div>
                </div>
              )}

              {/* Extracted Subjects List */}
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {parsedSubjects.map((s, idx) => {
                  const pages = Math.max(1, s.endPage - s.startPage + 1);
                  return (
                    <div
                      key={`${s.name}-${idx}`}
                      className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-2xl">{s.emoji}</span>
                        <div className="min-w-0">
                          <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {s.name}
                          </h5>
                          {s.chapters && s.chapters.length > 0 ? (
                            <span className="text-[10px] text-blue-600 dark:text-blue-400 block truncate">
                              {s.chapters.join(', ')}
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400">
                              {pages} pages total
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700">
                          <span className="text-[10px] text-slate-500">pp.</span>
                          <input
                            type="number"
                            value={s.startPage}
                            onChange={e => {
                              const val = parseInt(e.target.value, 10) || 1;
                              handleUpdateSubject(idx, val, s.endPage);
                            }}
                            className="w-10 text-center bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none"
                          />
                          <span className="text-slate-400">–</span>
                          <input
                            type="number"
                            value={s.endPage}
                            onChange={e => {
                              const val = parseInt(e.target.value, 10) || s.startPage;
                              handleUpdateSubject(idx, s.startPage, val);
                            }}
                            className="w-12 text-center bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteSubject(idx)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                          title="Remove subject"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {unrecognizedLines.length > 0 && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-[11px] text-slate-500 border border-slate-200 dark:border-slate-700">
                  <span className="font-bold">Note:</span> {unrecognizedLines.length} extra lines were skipped (headers/titles). You can add any missing subject above!
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Navigation Buttons */}
        <div className="p-4 sm:p-5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between gap-3">
          {step === 'grade' ? (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancel
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                if (step === 'input') setStep('grade');
                if (step === 'exam') setStep('input');
                if (step === 'confirm') setStep('exam');
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          )}

          {step === 'grade' && (
            <button
              type="button"
              onClick={() => setStep('input')}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition"
            >
              <span>Continue to Syllabus</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {step === 'input' && (
            <button
              type="button"
              onClick={handleProceedFromPortion}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition"
            >
              <span>Organize &amp; Set Exam</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {step === 'exam' && (
            <button
              type="button"
              onClick={handleProceedToConfirmation}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-500/20 active:scale-95 transition"
            >
              <span>Review Confirmation Plan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {step === 'confirm' && (
            <button
              type="button"
              onClick={handleFinalBuild}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 hover:from-emerald-500 hover:to-blue-500 text-white text-xs font-black shadow-lg shadow-emerald-500/25 active:scale-95 transition"
            >
              <Sparkles className="w-4 h-4" />
              <span>Build My Study Quest Now</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
