import { Subject, BadgeDef, DecorItem, ExamPeriod, AppState } from './types.ts';

export const STORAGE_KEY = 'grade10-test2-page-tracker-v1';

export const XP_PAGE = 10;
export const XP_SESSION = 25;
export const XP_SUBJECT = 100;
export const XP_BADGE = 50;
export const XP_QUIZ = 5;
export const XP_QUIZ_RIGHT = 2;

export const DEFAULT_REWARDS = '🍪 A snack, 📺 One short video, 🎮 One game round, 🚶 A quick walk';

// Default Examination Periods (Customizable by every student)
export const DEFAULT_EXAM_PERIODS: ExamPeriod[] = [
  { id: 'q2', name: 'Second Quarter Test (T2)', shortName: 'T2', date: '2026-12-15' },
  { id: 'q1', name: 'First Quarter Test (T1)', shortName: 'T1', date: '2026-11-20' },
  { id: 'q3', name: 'Third Quarter Test (T3)', shortName: 'T3', date: '2027-03-20' },
  { id: 'q4', name: 'Fourth Quarter Test (T4)', shortName: 'T4', date: '2027-06-10' },
  { id: 'midterm', name: 'Midterm Examination', shortName: 'Midterm', date: '2027-01-15' },
  { id: 'final', name: 'Final Examination', shortName: 'Final', date: '2027-06-25' }
];

export const GRADE_OPTIONS = [
  'Grade 1',
  'Grade 2',
  'Grade 3',
  'Grade 4',
  'Grade 5',
  'Grade 6',
  'Grade 7',
  'Grade 8',
  'Grade 9',
  'Grade 10',
  'Grade 11 (Natural Science)',
  'Grade 11 (Social Science)',
  'Grade 12 (Natural Science)',
  'Grade 12 (Social Science)',
  'Custom'
] as const;

// Authentic Grade 10 portions for Gibson School Systems 2026/2027 (preserves existing accounts)
export const GRADE_10_SUBJECTS: Subject[] = [
  { name: 'Amharic', emoji: '📝', hue: 335, ranges: [[1, 30], [48, 84], [85, 111], [126, 151]] },
  { name: 'Math', emoji: '📐', hue: 225, ranges: [[1, 67], [81, 170], [171, 239], [255, 364]] },
  { name: 'Physics', emoji: '⚡', hue: 265, ranges: [[1, 45], [59, 116], [117, 175], [190, 244]] },
  { name: 'Chemistry', emoji: '🧪', hue: 165, ranges: [[1, 46], [60, 105], [106, 164], [197, 296]] },
  { name: 'Biology', emoji: '🧬', hue: 130, ranges: [[1, 40], [51, 95], [96, 136], [143, 174]] },
  { name: 'Citizenship', emoji: '🤝', hue: 22, ranges: [[1, 53], [64, 113], [114, 144], [154, 211]] },
  { name: 'Geography', emoji: '🌍', hue: 190, ranges: [[1, 37], [55, 100], [101, 136], [151, 195]] },
  { name: 'Integrated English', emoji: '📖', hue: 300, ranges: [[1, 33], [34, 65], [48, 86], [99, 229]] },
  { name: 'Computer Education', emoji: '💻', hue: 205, ranges: [[1, 45], [62, 101], [102, 160], [178, 224]] },
  { name: 'Economics', emoji: '📈', hue: 42, ranges: [[1, 28], [49, 87], [88, 113], [134, 184]] },
  { name: 'History', emoji: '🏺', hue: 6, ranges: [[1, 37], [44, 110], [111, 163], [170, 228]] },
  { name: 'Afaan Oromoo', emoji: '💬', hue: 80, ranges: [[1, 15], [25, 47], [48, 70], [82, 102]] }
];

export const subjects: Subject[] = GRADE_10_SUBJECTS;

// Intelligent Curriculum Presets for Each Grade (Students can freely customize)
export function getDefaultSubjectsForGrade(grade: string): Subject[] {
  if (grade === 'Grade 10') {
    return GRADE_10_SUBJECTS;
  }

  if (grade === 'Grade 1' || grade === 'Grade 2') {
    return [
      { name: 'Mathematics', emoji: '🔢', hue: 210, ranges: [[1, 30], [31, 60], [61, 90], [91, 120]] },
      { name: 'English & Phonics', emoji: '🔤', hue: 330, ranges: [[1, 25], [26, 50], [51, 75], [76, 100]] },
      { name: 'Environmental Science', emoji: '🌿', hue: 140, ranges: [[1, 20], [21, 40], [41, 60], [61, 80]] },
      { name: 'Reading & Stories', emoji: '📚', hue: 45, ranges: [[1, 25], [26, 50], [51, 75], [76, 100]] },
      { name: 'Art & Craft', emoji: '🎨', hue: 280, ranges: [[1, 15], [16, 30], [31, 45], [46, 60]] }
    ];
  }

  if (grade === 'Grade 3' || grade === 'Grade 4' || grade === 'Grade 5') {
    return [
      { name: 'Mathematics', emoji: '📐', hue: 215, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'General Science', emoji: '🔬', hue: 150, ranges: [[1, 35], [36, 75], [76, 115], [116, 150]] },
      { name: 'English', emoji: '📖', hue: 310, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'Social Studies', emoji: '🌍', hue: 190, ranges: [[1, 30], [31, 65], [66, 95], [96, 130]] },
      { name: 'Citizenship', emoji: '🤝', hue: 25, ranges: [[1, 25], [26, 50], [51, 75], [76, 100]] },
      { name: 'Amharic', emoji: '📝', hue: 340, ranges: [[1, 30], [31, 60], [61, 90], [91, 120]] }
    ];
  }

  if (grade === 'Grade 6') {
    return [
      { name: 'Mathematics', emoji: '📐', hue: 220, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'General Science', emoji: '🧪', hue: 160, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'English', emoji: '📖', hue: 305, ranges: [[1, 40], [41, 80], [81, 120], [121, 165]] },
      { name: 'Social Studies', emoji: '🌍', hue: 195, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] },
      { name: 'Citizenship', emoji: '🤝', hue: 20, ranges: [[1, 30], [31, 60], [61, 90], [91, 120]] },
      { name: 'Information Technology (ICT)', emoji: '💻', hue: 260, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] },
      { name: 'Career & Tech', emoji: '🛠️', hue: 45, ranges: [[1, 25], [26, 50], [51, 75], [76, 100]] }
    ];
  }

  if (grade === 'Grade 7' || grade === 'Grade 8') {
    return [
      { name: 'Mathematics', emoji: '📐', hue: 220, ranges: [[1, 55], [56, 115], [116, 170], [171, 230]] },
      { name: 'General Science', emoji: '🔬', hue: 155, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'Social Studies', emoji: '🌍', hue: 190, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'Citizenship', emoji: '🤝', hue: 25, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] },
      { name: 'Information Technology', emoji: '💻', hue: 260, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'Amharic', emoji: '📝', hue: 335, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] }
    ];
  }

  if (grade === 'Grade 9') {
    return [
      { name: 'Mathematics', emoji: '📐', hue: 225, ranges: [[1, 60], [61, 120], [121, 180], [181, 240]] },
      { name: 'Physics', emoji: '⚡', hue: 265, ranges: [[1, 40], [41, 85], [86, 130], [131, 175]] },
      { name: 'Chemistry', emoji: '🧪', hue: 165, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'Biology', emoji: '🧬', hue: 130, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'Geography', emoji: '🌍', hue: 190, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] },
      { name: 'History', emoji: '🏺', hue: 10, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] },
      { name: 'Citizenship', emoji: '🤝', hue: 25, ranges: [[1, 30], [31, 60], [61, 90], [91, 120]] },
      { name: 'Economics', emoji: '📈', hue: 45, ranges: [[1, 30], [31, 60], [61, 90], [91, 120]] },
      { name: 'Computer Science', emoji: '💻', hue: 210, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] }
    ];
  }

  if (grade.includes('Grade 11') && grade.includes('Natural')) {
    return [
      { name: 'Advanced Mathematics', emoji: '📐', hue: 225, ranges: [[1, 75], [76, 150], [151, 225], [226, 300]] },
      { name: 'Physics', emoji: '⚡', hue: 265, ranges: [[1, 60], [61, 120], [121, 180], [181, 240]] },
      { name: 'Chemistry', emoji: '🧪', hue: 165, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'Biology', emoji: '🧬', hue: 130, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'Information Technology', emoji: '💻', hue: 210, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'Technical Drawing', emoji: '📏', hue: 40, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] }
    ];
  }

  if (grade.includes('Grade 11') && grade.includes('Social')) {
    return [
      { name: 'Mathematics (Social)', emoji: '📐', hue: 220, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'Economics', emoji: '📈', hue: 45, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'Geography', emoji: '🌍', hue: 190, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'History', emoji: '🏺', hue: 10, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
      { name: 'Business Education', emoji: '💼', hue: 160, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
      { name: 'Information Technology', emoji: '💻', hue: 210, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] }
    ];
  }

  if (grade.includes('Grade 12') && grade.includes('Natural')) {
    return [
      { name: 'Advanced Mathematics', emoji: '📐', hue: 225, ranges: [[1, 80], [81, 160], [161, 240], [241, 320]] },
      { name: 'Physics', emoji: '⚡', hue: 265, ranges: [[1, 65], [66, 130], [131, 195], [196, 260]] },
      { name: 'Chemistry', emoji: '🧪', hue: 165, ranges: [[1, 60], [61, 120], [121, 180], [181, 240]] },
      { name: 'Biology', emoji: '🧬', hue: 130, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'Information Technology', emoji: '💻', hue: 210, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] }
    ];
  }

  if (grade.includes('Grade 12') && grade.includes('Social')) {
    return [
      { name: 'Mathematics (Social)', emoji: '📐', hue: 220, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'Economics', emoji: '📈', hue: 45, ranges: [[1, 60], [61, 120], [121, 180], [181, 240]] },
      { name: 'Geography', emoji: '🌍', hue: 190, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'History', emoji: '🏺', hue: 10, ranges: [[1, 55], [56, 110], [111, 165], [166, 220]] },
      { name: 'English', emoji: '📖', hue: 300, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
      { name: 'Business & Management', emoji: '💼', hue: 160, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] }
    ];
  }

  // Custom or generic fallback
  return [
    { name: 'Mathematics', emoji: '📐', hue: 220, ranges: [[1, 50], [51, 100], [101, 150], [151, 200]] },
    { name: 'Science', emoji: '🔬', hue: 155, ranges: [[1, 45], [46, 90], [91, 135], [136, 180]] },
    { name: 'English / Language Arts', emoji: '📖', hue: 305, ranges: [[1, 40], [41, 80], [81, 120], [121, 160]] },
    { name: 'Social Studies / History', emoji: '🌍', hue: 190, ranges: [[1, 35], [36, 70], [71, 105], [106, 140]] }
  ];
}

export const MODES = {
  sprint: { label: 'Just 10 minutes', work: 10, brk: 0 },
  pomodoro: { label: 'Pomodoro', work: 25, brk: 5 },
  hardest: { label: 'Hardest subject first', work: 10, brk: 0 }
};

export const BADGES: BadgeDef[] = [
  { id: 'first', e: '🌱', n: 'First step', d: 'Log your first page', t: s => s.pages >= 1 },
  { id: 'p50', e: '📘', n: 'First 50 pages', d: 'Study 50 pages in total', t: s => s.pages >= 50 },
  { id: 'p200', e: '📚', n: '200 pages', d: 'Study 200 pages in total', t: s => s.pages >= 200 },
  { id: 'p500', e: '🏔️', n: '500 pages', d: 'Study 500 pages in total', t: s => s.pages >= 500 },
  { id: 'fin1', e: '🏁', n: 'Subject finished', d: 'Finish every page of one subject', t: s => s.fin >= 1 },
  { id: 'fin3', e: '🏆', n: 'Triple finish', d: 'Finish three subjects', t: s => s.fin >= 3 },
  { id: 'str3', e: '🔥', n: '3 days in a row', d: 'Study three days running', t: s => s.streak >= 3 },
  { id: 'str7', e: '🚀', n: 'One-week streak', d: 'Study seven days running', t: s => s.streak >= 7 },
  { id: 'early', e: '🌅', n: 'Early bird', d: 'Study before 8 AM', t: s => s.early },
  { id: 'focus1', e: '⏱️', n: 'First focus round', d: 'Finish a full timer', t: s => s.sessions >= 1 },
  { id: 'pomo3', e: '🍅', n: 'Pomodoro pro', d: 'Finish three 25-minute rounds', t: s => s.pomos >= 3 },
  { id: 'half', e: '🌗', n: 'Halfway there', d: 'Cover 50% of the active exam portion', t: s => s.pct >= 50 },
  { id: 'ready', e: '🎓', n: 'Test ready', d: 'Cover 100% of the active exam portion', t: s => s.pct >= 100 }
];

export const RANKS: [number, string][] = [
  [1, 'Rookie'],
  [3, 'Learner'],
  [5, 'Scholar'],
  [8, 'Master'],
  [10, 'Top of the Class']
];

export const DECOR: DecorItem[] = [
  { id: 'plant', n: 'Potted Fern', c: 3, x: 640, h: 76 },
  { id: 'candle', n: 'Amber Candle', c: 4, x: 780, h: 72 },
  { id: 'chair', n: 'Cozy Armchair', c: 6, x: 920, h: 62 },
  { id: 'frame', n: 'Nature Canvas', c: 8, x: 1070, h: 90 },
  { id: 'rug', n: 'Yarn Basket', c: 10, x: 1215, h: 56 },
  { id: 'books', n: 'Oak Bookshelf', c: 12, x: 1375, h: 98 }
];

export const xpFor = (n: number) => 50 * n * (n - 1);

export function levelOf(xp: number): number {
  let n = 1;
  while (xp >= xpFor(n + 1)) n++;
  return n;
}

export function rankOf(l: number): string {
  let r = RANKS[0][1];
  RANKS.forEach(([min, name]) => {
    if (l >= min) r = name;
  });
  return r;
}

export const pad = (n: number) => String(n).padStart(2, '0');
export const dayKey = (d: Date) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
export const todayKey = () => dayKey(new Date());
export const addDays = (d: Date, n: number) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
export const ord = (q: number) => ['1st', '2nd', '3rd', '4th'][q - 1] || q + 'th';
export const fmtTime = (ms: number) => {
  const t = Math.max(0, Math.ceil(ms / 1000));
  return pad(Math.floor(t / 60)) + ':' + pad(t % 60);
};

export const byName = (n: string, customList?: Subject[]) => {
  const list = customList && customList.length > 0 ? customList : subjects;
  return list.find(s => s.name === n);
};

export const countFor = (r: [number, number]) => {
  if (!r || r.length < 2) return 1;
  return Math.max(1, r[1] - r[0] + 1);
};

