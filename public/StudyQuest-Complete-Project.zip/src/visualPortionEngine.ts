import { loadPdfJs } from './quizEngine.ts';
import { lookupSubjectMetadata } from './portionParser.ts';

export interface SpatialTextItem {
  str: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontHeight: number;
}

export interface RenderedPdfPage {
  pageNumber: number;
  width: number;
  height: number;
  imageDataUrl: string;
  textItems: SpatialTextItem[];
  rawText: string;
}

export interface VisualExtractedSubject {
  id: string;
  examName: string;
  name: string;
  emoji: string;
  hue: number;
  startPage: number;
  endPage: number;
  topics: string[];
  sourcePageNumber: number;
  sourceBox?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  confidence: 'high' | 'uncertain';
  uncertaintyReason?: string;
  rawText?: string;
}

export interface VisualDocumentResult {
  detectedGrade?: string;
  detectedExamName?: string;
  detectedDate?: string;
  pages: RenderedPdfPage[];
  subjects: VisualExtractedSubject[];
  unrecognizedSections: string[];
  extractionMethod: 'multimodal_gemini' | 'spatial_visual_table';
}

/**
 * 1. Renders PDF pages to high-resolution HTML5 canvases and extracts
 * spatial text item coordinates.
 */
export async function renderPdfPages(
  file: File,
  onProgress?: (current: number, total: number, message: string) => void
): Promise<RenderedPdfPage[]> {
  onProgress?.(0, 1, 'Initializing high-fidelity visual PDF renderer…');
  const pdfjs = await loadPdfJs();
  const buffer = await file.arrayBuffer();
  const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
  const doc = await loadingTask.promise;
  const numPages = Math.min(doc.numPages, 10); // Process up to 10 pages for syllabus portions

  const renderedPages: RenderedPdfPage[] = [];

  for (let i = 1; i <= numPages; i++) {
    onProgress?.(i, numPages, `Rendering page ${i} of ${numPages} for visual inspection…`);
    const page = await doc.getPage(i);

    // 1.5x scale provides crisp text rendering and spatial accuracy
    const viewport = page.getViewport({ scale: 1.5 });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      page.cleanup();
      continue;
    }

    // Render original visual page
    await page.render({
      canvasContext: ctx,
      viewport: viewport
    }).promise;

    const imageDataUrl = canvas.toDataURL('image/jpeg', 0.88);

    // Extract text items with spatial bounding boxes
    const textContent = await page.getTextContent();
    const spatialItems: SpatialTextItem[] = [];
    let fullPageText = '';

    for (const item of textContent.items as any[]) {
      if (typeof item.str !== 'string' || !item.str.trim()) continue;
      const str = item.str.trim();
      fullPageText += str + ' ';

      // Extract transform coordinates [scaleX, skewY, skewX, scaleY, transX, transY]
      // PDF y-coordinates start at bottom; convert to top-down viewport coordinates
      if (item.transform && Array.isArray(item.transform)) {
        const tx = item.transform[4];
        const ty = item.transform[5];
        const pt = viewport.convertToViewportPoint(tx, ty);
        const fontH = Math.max(8, (item.height || 10) * 1.5);
        const w = Math.max(10, (item.width || 20) * 1.5);

        spatialItems.push({
          str,
          x: Math.max(0, pt[0]),
          y: Math.max(0, pt[1] - fontH), // align to top-left
          width: w,
          height: fontH,
          fontHeight: fontH
        });
      }
    }

    renderedPages.push({
      pageNumber: i,
      width: canvas.width,
      height: canvas.height,
      imageDataUrl,
      textItems: spatialItems,
      rawText: fullPageText.trim()
    });

    page.cleanup();
    // Allow UI thread to breathe
    await new Promise(r => setTimeout(r, 10));
  }

  return renderedPages;
}

/**
 * 2. Visual Document & Table Structure Analysis
 * Preserves columns, rows, headings, and visual cell relationships.
 * Maps subject names directly to the page ranges located in their row.
 */
export function analyzeVisualDocumentStructure(
  pages: RenderedPdfPage[],
  targetDefaultExamName: string,
  targetDefaultGrade: string
): VisualDocumentResult {
  let detectedGrade = targetDefaultGrade;
  let detectedExamName = targetDefaultExamName;
  let detectedDate: string | undefined;

  const extractedSubjects: VisualExtractedSubject[] = [];
  const unrecognizedSections: string[] = [];

  const gradeRegex = /\b(?:grade|gr\.?|class)\s*(\d{1,2})\b/i;
  const examRegex = /\b(first quarter test|fqt|second quarter test|test 2|third quarter test|test 3|fourth quarter test|test 4|midterm|final exam|finals|unit test|monthly test)\b/i;
  const dateRegex = /\b(?:202[6-9][-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]202[6-9]|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s*(?:202[6-9])?)\b/i;

  for (const page of pages) {
    // 1. Check page text for global document metadata
    const gm = page.rawText.match(gradeRegex);
    if (gm) detectedGrade = `Grade ${gm[1]}`;

    const em = page.rawText.match(examRegex);
    if (em) detectedExamName = normalizeExamName(em[0]);

    const dm = page.rawText.match(dateRegex);
    if (dm && !detectedDate) detectedDate = dm[0];

    // If no spatial items exist (scanned or image PDF), check if fallback is needed
    if (page.textItems.length === 0) {
      continue;
    }

    // 2. Group spatial items into visual horizontal lines/rows based on y-coordinate
    // Items with vertical centers within ~8px belong to the same visual line/row
    const sortedItems = [...page.textItems].sort((a, b) => a.y - b.y || a.x - b.x);
    const rows: { y: number; height: number; items: SpatialTextItem[] }[] = [];

    for (const item of sortedItems) {
      let matchedRow = rows.find(r => Math.abs(r.y - item.y) <= Math.max(8, item.fontHeight * 0.7));
      if (!matchedRow) {
        matchedRow = { y: item.y, height: item.height, items: [] };
        rows.push(matchedRow);
      }
      matchedRow.items.push(item);
      // update average row y and max height
      matchedRow.height = Math.max(matchedRow.height, item.height);
    }

    // Sort rows top-to-bottom
    rows.sort((a, b) => a.y - b.y);

    // Keep track of the active examination in this document section
    // (e.g. if a table has "First Quarter Test (FQT)" at the top and "Second Quarter Test (Test 2)" later)
    let currentSectionExam = detectedExamName || targetDefaultExamName;

    // Analyze each visual row
    for (const row of rows) {
      // Sort items within row left-to-right
      row.items.sort((a, b) => a.x - b.x);

      const rowStr = row.items.map(it => it.str).join(' ');

      // Check if this row is an Examination Section Banner Header
      const rowExamMatch = rowStr.match(examRegex);
      if (rowExamMatch) {
        currentSectionExam = normalizeExamName(rowExamMatch[0]);
        continue;
      }

      // Check if this row is a Table Header (e.g. "No. | Subject | Portion / Chapter | Pages | Date")
      if (isTableHeaderRow(rowStr)) {
        continue;
      }

      // Try table-column extraction:
      // Look for Subject cell and Page range cell within this same row
      const candidate = extractSubjectAndRangeFromRow(row, currentSectionExam, page.pageNumber);
      if (candidate) {
        extractedSubjects.push(candidate);
      } else if (rowStr.length > 5 && !/^(?:school|grade|date|academic|student|time|signature|notice)/i.test(rowStr)) {
        // Only keep genuinely unrecognized lines
        if (/\d/.test(rowStr) || /[a-z]{3,}/i.test(rowStr)) {
          unrecognizedSections.push(`Page ${page.pageNumber}: ${rowStr}`);
        }
      }
    }
  }

  // Deduplicate subjects by (examName + subjectName)
  const uniqueSubjects: VisualExtractedSubject[] = [];
  const seenKeys = new Set<string>();

  for (const s of extractedSubjects) {
    const key = `${s.examName.toLowerCase()}|${s.name.toLowerCase()}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      uniqueSubjects.push(s);
    }
  }

  return {
    detectedGrade,
    detectedExamName,
    detectedDate,
    pages,
    subjects: uniqueSubjects,
    unrecognizedSections: unrecognizedSections.slice(0, 15),
    extractionMethod: 'spatial_visual_table'
  };
}

/**
 * Extracts a subject and its exact row-aligned page range from a visual row
 */
function extractSubjectAndRangeFromRow(
  row: { y: number; height: number; items: SpatialTextItem[] },
  examName: string,
  pageNumber: number
): VisualExtractedSubject | null {
  const sorted = [...row.items].sort((a, b) => a.x - b.x);
  const rowStr = sorted.map(it => it.str).join(' ');
  const normalized = rowStr
    .replace(/[–—−]/g, '-')
    .replace(/\bto\b/gi, '-')
    .replace(/\btill\b/gi, '-')
    .replace(/\bthrough\b/gi, '-');

  // Regex to extract page range: e.g. "45-80", "1 - 35", "pp. 81 - 170", "pages 10-45"
  const rangeMatch = normalized.match(/(?:pages?|pp\.?|p\.?)?\s*(\d{1,4})\s*-\s*(\d{1,4})/i);

  if (!rangeMatch) {
    return null;
  }

  const startPage = parseInt(rangeMatch[1], 10);
  const endPage = parseInt(rangeMatch[2], 10);

  if (isNaN(startPage) || isNaN(endPage) || endPage < startPage) {
    return null;
  }

  // 1. Identify which spatial item contains the page range
  let rangeItemIdx = -1;
  for (let i = 0; i < sorted.length; i++) {
    const itemNorm = sorted[i].str.replace(/[–—−]/g, '-').replace(/\bto\b/gi, '-');
    if (
      /\b\d{1,4}\s*-\s*\d{1,4}\b/.test(itemNorm) ||
      (itemNorm.includes('-') && itemNorm.includes(rangeMatch[1]) && itemNorm.includes(rangeMatch[2]))
    ) {
      rangeItemIdx = i;
      break;
    }
  }

  // Items before the page range column
  const beforeItems = (rangeItemIdx > 0 ? sorted.slice(0, rangeItemIdx) : sorted)
    .filter(it => !/^(?:\d+[\.\)\-]?|#\d+|[•▪●◦■□–\-])$/.test(it.str.trim()));

  let rawSubjectName = '';
  let topics: string[] = [];

  const knownSubjects = [
    'mathematics', 'math', 'physics', 'chemistry', 'biology', 'science',
    'general science', 'environmental science', 'english', 'integrated english',
    'amharic', 'afaan oromoo', 'oromiffa', 'geography', 'history',
    'social studies', 'citizenship', 'civics', 'economics', 'computer education',
    'computer science', 'ict', 'information technology', 'business', 'art',
    'music', 'reading', 'french', 'arabic', 'technical drawing', 'agriculture'
  ];

  if (beforeItems.length === 1) {
    const text = beforeItems[0].str.trim();
    const tm = text.match(/\b(unit|chapter|lesson|topic|part)\s*[\d\w,\s&]+[:|\-–—\s]*/i);
    if (tm) {
      topics.push(tm[0].trim());
      rawSubjectName = text.replace(tm[0], '').trim();
    } else {
      rawSubjectName = text;
    }
  } else if (beforeItems.length >= 2) {
    let matchedSubjIdx = -1;
    for (let i = 0; i < beforeItems.length; i++) {
      const itStr = beforeItems[i].str.toLowerCase().trim();
      if (knownSubjects.some(ks => itStr === ks || itStr.startsWith(ks) || itStr.endsWith(ks))) {
        matchedSubjIdx = i;
        break;
      }
    }

    if (matchedSubjIdx !== -1) {
      rawSubjectName = beforeItems[matchedSubjIdx].str.trim();
      const otherItems = beforeItems.filter((_, idx) => idx !== matchedSubjIdx);
      topics = otherItems.map(it => it.str.trim()).filter(Boolean);
    } else {
      rawSubjectName = beforeItems[0].str.trim();
      topics = beforeItems.slice(1).map(it => it.str.trim()).filter(Boolean);
    }
  } else {
    const beforeRange = normalized.split(rangeMatch[0])[0].trim();
    let cleanLead = beforeRange.replace(/^(?:\d+[\.\)\-]\s*|#\d+\s*|[•▪●◦■□–\-])/, '').trim();
    const tm = cleanLead.match(/\b(unit|chapter|lesson|topic|part)\s*[\d\w,\s&]+[:|\-–—\s]*/i);
    if (tm) {
      topics.push(tm[0].trim());
      cleanLead = cleanLead.replace(tm[0], '').trim();
    }
    rawSubjectName = cleanLead;
  }

  // Standardize subject name
  const formattedName = cleanSubjectTitle(rawSubjectName);
  if (!formattedName || formattedName.length < 2) {
    return null;
  }

  const meta = lookupSubjectMetadata(formattedName);

  // Compute spatial bounding box from row items
  const minX = Math.min(...row.items.map(it => it.x));
  const maxX = Math.max(...row.items.map(it => it.x + it.width));
  const minY = Math.min(...row.items.map(it => it.y));
  const maxY = Math.max(...row.items.map(it => it.y + it.height));

  return {
    id: `subj-${pageNumber}-${Math.round(minY)}-${Math.random().toString(36).slice(2, 6)}`,
    examName,
    name: formattedName,
    emoji: meta.emoji,
    hue: meta.hue,
    startPage,
    endPage,
    topics: topics.length > 0 ? topics : ['Full Portion'],
    sourcePageNumber: pageNumber,
    sourceBox: {
      x: Math.round(minX),
      y: Math.round(minY),
      width: Math.round(maxX - minX),
      height: Math.round(maxY - minY)
    },
    confidence: 'high',
    rawText: rowStr
  };
}

/**
 * 3. Multimodal Analysis via Server Proxy (/api/analyze-portion)
 * If an API key is available, calls Gemini 3.8 Flash with rendered page images.
 * Returns null if server/API is not active, triggering local spatial engine.
 */
export async function tryMultimodalAnalysis(
  pages: RenderedPdfPage[],
  defaultExamName: string,
  grade: string
): Promise<VisualDocumentResult | null> {
  try {
    const images = pages.map(p => p.imageDataUrl);
    const res = await fetch('/api/analyze-portion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        images,
        defaultExamName,
        grade
      })
    });

    if (!res.ok) {
      return null;
    }

    const data = await res.json();
    if (!data.success || !data.data || !Array.isArray(data.data.subjects)) {
      return null;
    }

    const aiData = data.data;
    const subjects: VisualExtractedSubject[] = [];

    for (let idx = 0; idx < aiData.subjects.length; idx++) {
      const s = aiData.subjects[idx];
      if (!s.name) continue;

      const formattedName = cleanSubjectTitle(s.name);
      const meta = lookupSubjectMetadata(formattedName);
      const srcPg = Math.min(Math.max(1, s.sourcePageNumber || 1), pages.length);
      const targetPage = pages[srcPg - 1];

      // Find spatial bounding box on that page matching subject name
      let sourceBox: { x: number; y: number; width: number; height: number } | undefined;
      if (targetPage && targetPage.textItems.length > 0) {
        const query = formattedName.toLowerCase();
        const matchedItem = targetPage.textItems.find(it => it.str.toLowerCase().includes(query.slice(0, 4)));
        if (matchedItem) {
          sourceBox = {
            x: Math.max(0, matchedItem.x - 10),
            y: Math.max(0, matchedItem.y - 6),
            width: Math.min(targetPage.width, matchedItem.width + 250),
            height: Math.max(30, matchedItem.height + 15)
          };
        }
      }

      const isUncertain = s.confidence === 'uncertain' || s.startPage == null || s.endPage == null;
      const startP = s.startPage != null ? Number(s.startPage) : 1;
      const endP = s.endPage != null ? Math.max(startP, Number(s.endPage)) : startP + 35;

      subjects.push({
        id: `ai-subj-${idx}-${Math.random().toString(36).slice(2, 6)}`,
        examName: s.examName ? normalizeExamName(s.examName) : defaultExamName,
        name: formattedName,
        emoji: meta.emoji,
        hue: meta.hue,
        startPage: startP,
        endPage: endP,
        topics: Array.isArray(s.topics) ? s.topics : [],
        sourcePageNumber: srcPg,
        sourceBox,
        confidence: isUncertain ? 'uncertain' : 'high',
        uncertaintyReason: isUncertain ? (s.notes || 'Page range uncertain in visual table') : undefined,
        rawText: s.notes
      });
    }

    return {
      detectedGrade: aiData.detectedGrade || grade,
      detectedExamName: aiData.detectedExamName ? normalizeExamName(aiData.detectedExamName) : defaultExamName,
      detectedDate: aiData.detectedDate,
      pages,
      subjects,
      unrecognizedSections: [],
      extractionMethod: 'multimodal_gemini'
    };
  } catch (err) {
    console.warn('Multimodal fetch fallback:', err);
    return null;
  }
}

/**
 * Normalizes examination names (e.g. "Test 2", "FQT", "Midterm")
 */
export function normalizeExamName(raw: string): string {
  const l = raw.trim().toLowerCase();
  if (l.includes('fqt') || l.includes('first quarter') || l.includes('1st quarter')) {
    return 'First Quarter Test (FQT)';
  }
  if (l.includes('test 2') || l.includes('second quarter') || l.includes('2nd quarter')) {
    return 'Second Quarter Test (Test 2)';
  }
  if (l.includes('test 3') || l.includes('third quarter') || l.includes('3rd quarter')) {
    return 'Third Quarter Test (Test 3)';
  }
  if (l.includes('test 4') || l.includes('fourth quarter') || l.includes('4th quarter')) {
    return 'Fourth Quarter Test (Test 4)';
  }
  if (l.includes('midterm')) {
    return 'Midterm Examination';
  }
  if (l.includes('final')) {
    return 'Final Examination';
  }
  // Title-case custom names
  return raw
    .split(' ')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Checks if a row is a table header
 */
function isTableHeaderRow(rowStr: string): boolean {
  const norm = rowStr.toLowerCase();
  // If the row contains an actual page range like "1-67" or "pages 45-80", it is a data row, NOT a header!
  if (/(?:pages?|pp\.?|p\.?)?\s*\d{1,4}\s*-\s*\d{1,4}/.test(norm)) {
    return false;
  }
  const hasSubjectHeader = /\b(subject|course|discipline|subject\s*name)\b/i.test(norm);
  const hasOtherHeader = /\b(portion|topics?|chapters?|units?|pages?|pp\.?|page\s*no|date|remarks|s\.?no|no\.)\b/i.test(norm);
  return hasSubjectHeader && hasOtherHeader;
}

/**
 * Clean and title-case subject name
 */
function cleanSubjectTitle(raw: string): string {
  let cleaned = raw
    .replace(/^(?:\d+[\.\)\-]\s*|#\d+\s*|[•▪●◦■□–\-])/, '')
    .replace(/[^\w\s&'-]/g, ' ')
    .replace(/\b(pages?|pp\.?|portion|test|exam|unit|chapter|lesson|grade)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) return '';

  return cleaned
    .split(' ')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}
