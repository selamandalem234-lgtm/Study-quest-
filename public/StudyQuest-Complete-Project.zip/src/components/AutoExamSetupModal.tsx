import React, { useState, useRef } from 'react';
import { Subject, ExamRecord, StudyPortion } from '../types.ts';
import {
  GRADE_OPTIONS,
  STANDARD_EXAM_PRESETS,
  getDefaultSubjectsForGrade,
  GRADE_10_SUBJECTS
} from '../constants.ts';
import {
  renderPdfPages,
  analyzeVisualDocumentStructure,
  tryMultimodalAnalysis,
  RenderedPdfPage,
  VisualExtractedSubject,
  VisualDocumentResult,
  normalizeExamName
} from '../visualPortionEngine.ts';
import {
  parsePortionDivisionText,
  lookupSubjectMetadata,
  ParsedSubjectPortion
} from '../portionParser.ts';
import { VisualPdfInspectorModal } from './VisualPdfInspectorModal.tsx';
import {
  Sparkles,
  FileText,
  Upload,
  Calendar,
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  X,
  ArrowRight,
  ArrowLeft,
  Edit2,
  Trash2,
  Plus,
  BookOpen,
  Camera,
  Layers,
  Clock,
  ShieldCheck,
  Check,
  Eye,
  Search,
  Maximize2,
  HelpCircle,
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AutoExamSetupModalProps {
  currentGrade: string;
  currentActiveExamId: string;
  existingExams?: Record<string, ExamRecord>;
  onApplySetup: (setup: {
    grade: string;
    examId: string;
    examName: string;
    shortName: string;
    quarter: number;
    targetDate: string;
    subjects: Subject[];
    multiExamPayload?: Record<string, {
      examName: string;
      shortName: string;
      quarter: number;
      targetDate: string;
      subjects: Subject[];
    }>;
  }) => void;
  onClose: () => void;
  isInitial?: boolean;
}

export const AutoExamSetupModal: React.FC<AutoExamSetupModalProps> = ({
  currentGrade,
  currentActiveExamId,
  existingExams,
  onApplySetup,
  onClose,
  isInitial = false
}) => {
  // Step 1: Grade Selection
  // Step 2: Choose Examination Period
  // Step 3: Enter / Upload Portions (Visual PDF, Photo, Text Paste)
  // Step 4: Structured Visual Verification Preview
  const [step, setStep] = useState<'grade' | 'exam' | 'input' | 'confirm'>('grade');

  // Grade State
  const [grade, setGrade] = useState<string>(currentGrade || 'Grade 10');
  const [customGrade, setCustomGrade] = useState<string>('');

  // Exam Selection State
  const initialPreset = STANDARD_EXAM_PRESETS.find(p => p.id === currentActiveExamId) || STANDARD_EXAM_PRESETS[1];
  const [selectedExamId, setSelectedExamId] = useState<string>(initialPreset.id);
  const [customExamName, setCustomExamName] = useState<string>('');
  const [quarterNum, setQuarterNum] = useState<number>(initialPreset.quarter);
  const [examDate, setExamDate] = useState<string>(initialPreset.defaultDate);

  // Input Tabs & File Processing State
  const [inputMode, setInputMode] = useState<'pdf' | 'photo' | 'paste'>('pdf');
  const [portionText, setPortionText] = useState<string>('');
  const [isProcessingFile, setIsProcessingFile] = useState<boolean>(false);
  const [processStatusMessage, setProcessStatusMessage] = useState<string>('');
  const [fileError, setFileError] = useState<string | null>(null);

  // Visual Document Understanding State
  const [renderedPdfPages, setRenderedPdfPages] = useState<RenderedPdfPage[]>([]);
  const [extractedSubjects, setExtractedSubjects] = useState<VisualExtractedSubject[]>([]);
  const [extractionMethod, setExtractionMethod] = useState<'multimodal_gemini' | 'spatial_visual_table' | 'text_parser'>('spatial_visual_table');
  const [unrecognizedLines, setUnrecognizedLines] = useState<string[]>([]);
  const [inspectingSubject, setInspectingSubject] = useState<VisualExtractedSubject | null>(null);

  // Inline Subject Editing State in Step 4
  const [editingSubjId, setEditingSubjId] = useState<string | null>(null);
  const [showAddSubj, setShowAddSubj] = useState<boolean>(false);
  const [newSubExam, setNewSubExam] = useState<string>('');
  const [newSubName, setNewSubName] = useState<string>('');
  const [newSubStart, setNewSubStart] = useState<string>('1');
  const [newSubEnd, setNewSubEnd] = useState<string>('50');
  const [newSubTopics, setNewSubTopics] = useState<string>('');

  const pdfInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Computed Exam Names
  const activePreset = STANDARD_EXAM_PRESETS.find(p => p.id === selectedExamId);
  const effectiveExamName = selectedExamId === 'custom'
    ? (customExamName.trim() || 'Custom Examination')
    : (activePreset?.name || 'Second Quarter Test (Test 2)');

  const effectiveShortName = selectedExamId === 'custom'
    ? (customExamName.trim().slice(0, 10) || 'Custom')
    : (activePreset?.shortName || 'Test 2');

  const effectiveGrade = grade === 'Custom' && customGrade.trim() ? customGrade.trim() : grade;

  // Handlers for Visual PDF Upload
  const handlePdfUpload = async (file: File) => {
    setIsProcessingFile(true);
    setFileError(null);
    setProcessStatusMessage('Opening textbook syllabus PDF…');

    try {
      // 1. Render all PDF pages to HTML5 canvas and extract spatial bounding box coordinates
      const pages = await renderPdfPages(file, (_cur, _tot, msg) => {
        setProcessStatusMessage(msg);
      });

      if (!pages || pages.length === 0) {
        throw new Error('No readable pages found in PDF');
      }

      setRenderedPdfPages(pages);
      setProcessStatusMessage('Analyzing visual document structure, tables, and rows…');

      // 2. Try multimodal Gemini 3.8 Flash analysis first (if server API key configured)
      let result: VisualDocumentResult | null = await tryMultimodalAnalysis(
        pages,
        effectiveShortName,
        effectiveGrade
      );

      // 3. Fallback to client-side spatial visual table engine if no API key or offline
      if (!result || result.subjects.length === 0) {
        setProcessStatusMessage('Running spatial visual table and column analysis…');
        result = analyzeVisualDocumentStructure(pages, effectiveShortName, effectiveGrade);
      } else {
        setExtractionMethod('multimodal_gemini');
      }

      if (result.extractionMethod !== 'multimodal_gemini') {
        setExtractionMethod('spatial_visual_table');
      }

      if (result.subjects.length > 0) {
        setExtractedSubjects(result.subjects);
        setUnrecognizedLines(result.unrecognizedSections);
        if (result.detectedDate) setExamDate(result.detectedDate);
        setStep('confirm');
      } else {
        // If no subjects found, let user review or paste text
        setFileError('Could not detect distinct table rows in PDF. You can paste or type portions below.');
        setInputMode('paste');
      }
    } catch (err: any) {
      console.error('Visual PDF error:', err);
      setFileError('Could not render PDF visually. Please verify the file is a valid PDF.');
    } finally {
      setIsProcessingFile(false);
      setProcessStatusMessage('');
    }
  };

  // Handlers for Photo / Image Upload
  const handlePhotoUpload = async (file: File) => {
    setIsProcessingFile(true);
    setFileError(null);
    setProcessStatusMessage('Loading syllabus photo…');

    try {
      const reader = new FileReader();
      const dataUrl = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Create a mock rendered page for this photo
      const img = new Image();
      img.src = dataUrl;
      await new Promise(r => { img.onload = r; });

      const photoPage: RenderedPdfPage = {
        pageNumber: 1,
        width: img.naturalWidth || 800,
        height: img.naturalHeight || 1000,
        imageDataUrl: dataUrl,
        textItems: [],
        rawText: 'Photo Syllabus'
      };

      setRenderedPdfPages([photoPage]);
      setProcessStatusMessage('Analyzing photo visually with Gemini 3.8 Flash…');

      const result = await tryMultimodalAnalysis([photoPage], effectiveShortName, effectiveGrade);

      if (result && result.subjects.length > 0) {
        setExtractionMethod('multimodal_gemini');
        setExtractedSubjects(result.subjects);
        if (result.detectedDate) setExamDate(result.detectedDate);
        setStep('confirm');
      } else {
        // Fallback to sample or manual text
        handleLoadSample(effectiveGrade, selectedExamId);
        setInputMode('paste');
        setFileError('Could not read table from photo automatically. Loaded standard syllabus template to review.');
      }
    } catch (err) {
      console.error('Photo upload error:', err);
      setFileError('Could not process photo. Please paste or enter syllabus text.');
    } finally {
      setIsProcessingFile(false);
      setProcessStatusMessage('');
    }
  };

  // Direct Text Parser Handler
  const handleParseTextAndReview = () => {
    const text = portionText.trim();
    if (!text) {
      // Load fallback portions for this specific exam & grade
      const isG10 = effectiveGrade === 'Grade 10';
      const baseList = isG10 ? GRADE_10_SUBJECTS : getDefaultSubjectsForGrade(effectiveGrade);
      const qIdx = activePreset ? activePreset.quarterIndex : (quarterNum - 1);
      const converted: VisualExtractedSubject[] = baseList.map((d, i) => {
        const r = (d.ranges && d.ranges[qIdx]) || d.ranges?.[0] || [1, 50];
        return {
          id: `manual-${i}`,
          examName: effectiveShortName,
          name: d.name,
          emoji: d.emoji,
          hue: d.hue,
          startPage: r[0],
          endPage: r[1],
          topics: ['Full Portion'],
          sourcePageNumber: 1,
          confidence: 'high'
        };
      });
      setExtractionMethod('text_parser');
      setExtractedSubjects(converted);
    } else {
      const parsed = parsePortionDivisionText(text);
      const converted: VisualExtractedSubject[] = parsed.subjects.map((s, i) => ({
        id: `parsed-${i}`,
        examName: effectiveShortName,
        name: s.name,
        emoji: s.emoji,
        hue: s.hue,
        startPage: s.startPage,
        endPage: s.endPage,
        topics: s.chapters || ['Chapter Portion'],
        sourcePageNumber: 1,
        confidence: 'high'
      }));
      setExtractionMethod('text_parser');
      setExtractedSubjects(converted);
      setUnrecognizedLines(parsed.unrecognizedLines);
    }

    setStep('confirm');
  };

  // Sample Syllabus Loader tailored to grade and exam
  const handleLoadSample = (g: string, examId: string) => {
    if (g === 'Grade 10') {
      if (examId === 'fqt') {
        setPortionText(
          `Amharic: pages 1–30\nMath: pages 1–67 (Relations and Functions)\nPhysics: pages 1–45 (Vectors)\nChemistry: pages 1–46 (Chemical Bonding)\nBiology: pages 1–40 (Ecosystems)\nCitizenship: pages 1–53 (Democracy & Human Rights)\nGeography: pages 1–37 (Physical Geography)\nIntegrated English: pages 1–33\nComputer Education: pages 1–45 (Hardware Architecture)\nEconomics: pages 1–28 (Economic Systems)\nHistory: pages 1–37 (Early Civilizations)\nAfaan Oromoo: pages 1–15`
        );
      } else if (examId === 'test2') {
        setPortionText(
          `Amharic: pages 48–84\nMath: pages 81–170 (Coordinate Geometry & Polynomials)\nPhysics: pages 59–116 (Newton's Laws of Motion)\nChemistry: pages 60–105 (Stoichiometry)\nBiology: pages 51–95 (Genetics & Heredity)\nCitizenship: pages 64–113 (Rule of Law)\nGeography: pages 55–100 (Climate & Vegetation)\nIntegrated English: pages 34–65\nComputer Education: pages 62–101 (Programming Fundamentals)\nEconomics: pages 49–87 (Demand and Supply)\nHistory: pages 44–110 (Modern World History)\nAfaan Oromoo: pages 25–47`
        );
      } else {
        setPortionText(
          `Amharic: pages 48–84\nMath: pages 81–170\nPhysics: pages 59–116\nChemistry: pages 60–105\nBiology: pages 51–95\nCitizenship: pages 64–113\nGeography: pages 55–100\nIntegrated English: pages 34–65\nComputer Education: pages 62–101\nEconomics: pages 49–87\nHistory: pages 44–110\nAfaan Oromoo: pages 25–47`
        );
      }
    } else {
      const presets = getDefaultSubjectsForGrade(g);
      const qIdx = activePreset ? activePreset.quarterIndex : 0;
      const sample = presets
        .map(p => {
          const r = p.ranges[qIdx] || p.ranges[0] || [1, 40];
          return `${p.name}: pages ${r[0]}–${r[1]}`;
        })
        .join('\n');
      setPortionText(sample);
    }
  };

  // Inline Subject Updates in Step 4
  const handleUpdateSubject = (
    id: string,
    updates: Partial<VisualExtractedSubject>
  ) => {
    setExtractedSubjects(prev =>
      prev.map(s => (s.id === id ? { ...s, ...updates, confidence: 'high' } : s))
    );
  };

  const handleDeleteSubject = (id: string) => {
    setExtractedSubjects(prev => prev.filter(s => s.id !== id));
  };

  const handleAddNewSubject = () => {
    if (!newSubName.trim()) return;
    const start = parseInt(newSubStart, 10) || 1;
    const end = Math.max(start, parseInt(newSubEnd, 10) || start + 30);
    const meta = lookupSubjectMetadata(newSubName);

    const newSubj: VisualExtractedSubject = {
      id: `manual-new-${Date.now()}`,
      examName: newSubExam || effectiveShortName,
      name: newSubName.trim(),
      emoji: meta.emoji,
      hue: meta.hue,
      startPage: start,
      endPage: end,
      topics: newSubTopics ? [newSubTopics.trim()] : ['Custom Portion'],
      sourcePageNumber: 1,
      confidence: 'high'
    };

    setExtractedSubjects(prev => [...prev, newSubj]);
    setNewSubName('');
    setNewSubStart('1');
    setNewSubEnd('50');
    setNewSubTopics('');
    setShowAddSubj(false);
  };

  // Step 5: Save & Apply Study Plan ONLY after User Confirmation
  const handleFinalBuild = () => {
    if (extractedSubjects.length === 0) return;

    // Check if the extracted subjects span multiple examinations
    const examBuckets: Record<string, VisualExtractedSubject[]> = {};
    for (const s of extractedSubjects) {
      const eName = s.examName || effectiveShortName;
      if (!examBuckets[eName]) examBuckets[eName] = [];
      examBuckets[eName].push(s);
    }

    const multiExamPayload: Record<string, {
      examName: string;
      shortName: string;
      quarter: number;
      targetDate: string;
      subjects: Subject[];
    }> = {};

    for (const [eName, sList] of Object.entries(examBuckets)) {
      // Find matching preset id or create clean slug
      const matchedPreset = STANDARD_EXAM_PRESETS.find(p =>
        p.name.toLowerCase() === eName.toLowerCase() ||
        p.shortName.toLowerCase() === eName.toLowerCase()
      );
      const eId = matchedPreset ? matchedPreset.id : eName.toLowerCase().replace(/[^a-z0-9]/g, '_');

      const convertedSubjects: Subject[] = sList.map(item => ({
        name: item.name,
        emoji: item.emoji,
        hue: item.hue,
        ranges: [[item.startPage, item.endPage]],
        portions: item.topics.map((t, idx) => ({
          id: `p-${item.name}-${idx}`,
          title: t,
          startPage: item.startPage,
          endPage: item.endPage
        }))
      }));

      multiExamPayload[eId] = {
        examName: matchedPreset?.name || eName,
        shortName: matchedPreset?.shortName || eName,
        quarter: matchedPreset?.quarter || quarterNum,
        targetDate: matchedPreset?.defaultDate || examDate,
        subjects: convertedSubjects
      };
    }

    // Default primary exam
    const primarySubjects: Subject[] = (examBuckets[effectiveShortName] || extractedSubjects).map(item => ({
      name: item.name,
      emoji: item.emoji,
      hue: item.hue,
      ranges: [[item.startPage, item.endPage]],
      portions: item.topics.map((t, idx) => ({
        id: `p-${item.name}-${idx}`,
        title: t,
        startPage: item.startPage,
        endPage: item.endPage
      }))
    }));

    confetti({ particleCount: 90, spread: 80, origin: { y: 0.5 } });

    onApplySetup({
      grade: effectiveGrade,
      examId: selectedExamId,
      examName: effectiveExamName,
      shortName: effectiveShortName,
      quarter: quarterNum,
      targetDate: examDate,
      subjects: primarySubjects,
      multiExamPayload
    });

    onClose();
  };

  const totalPagesWorkload = extractedSubjects.reduce(
    (acc, s) => acc + Math.max(1, s.endPage - s.startPage + 1),
    0
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/70 dark:bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[92vh] rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-black shadow-md shadow-blue-500/20">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Visual Portion Division & Exam Setup</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300">
                  Visual Layout Engine
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Visual table recognition, exact page ranges, and multi-examination separation
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-Step Wizard Progress Bar */}
        <div className="px-6 py-3 bg-slate-100/60 dark:bg-slate-800/40 border-b border-slate-200/60 dark:border-white/5 flex items-center justify-between text-xs font-bold">
          <div className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'grade' ? 'bg-blue-600 text-white' : 'bg-emerald-500 text-white'}`}>
              1
            </span>
            <span className={step === 'grade' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400'}>
              Grade Level
            </span>
          </div>
          <span className="text-slate-300 dark:text-slate-700">───</span>
          <div className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'exam' ? 'bg-blue-600 text-white' : (step === 'input' || step === 'confirm') ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}`}>
              2
            </span>
            <span className={step === 'exam' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400'}>
              Target Exam
            </span>
          </div>
          <span className="text-slate-300 dark:text-slate-700">───</span>
          <div className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'input' ? 'bg-blue-600 text-white' : step === 'confirm' ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}`}>
              3
            </span>
            <span className={step === 'input' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400'}>
              Visual Read
            </span>
          </div>
          <span className="text-slate-300 dark:text-slate-700">───</span>
          <div className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'confirm' ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}`}>
              4
            </span>
            <span className={step === 'confirm' ? 'text-blue-600 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400'}>
              Structured Preview
            </span>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* STEP 1: GRADE SELECTION */}
          {step === 'grade' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col gap-1">
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Which grade level are you preparing for?</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Select Grade 1 through 12, or choose custom. Study Quest calibrates subjects and textbooks specifically for your grade.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {GRADE_OPTIONS.map(g => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGrade(g)}
                    className={`py-3 px-3 rounded-2xl text-xs font-bold transition-all border text-center ${
                      grade === g
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/25 ring-2 ring-blue-500/20'
                        : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-white/5 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>

              {grade === 'Custom' && (
                <div className="pt-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Enter Custom Grade or Level:
                  </label>
                  <input
                    type="text"
                    value={customGrade}
                    onChange={e => setCustomGrade(e.target.value)}
                    placeholder="e.g. University Year 1 or AP Biology"
                    className="w-full h-11 px-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  />
                </div>
              )}
            </div>
          )}

          {/* STEP 2: CHOOSE TARGET EXAMINATION */}
          {step === 'exam' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col gap-1">
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Which examination does this portion division belong to?
                </h4>
                <p className="text-xs text-slate-500">
                  Test 2 and FQT are completely separate examinations with isolated page ranges.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {STANDARD_EXAM_PRESETS.map(preset => {
                  const isSelected = selectedExamId === preset.id;
                  return (
                    <div
                      key={preset.id}
                      onClick={() => {
                        setSelectedExamId(preset.id);
                        setQuarterNum(preset.quarter);
                        setExamDate(preset.defaultDate);
                      }}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col gap-1.5 ${
                        isSelected
                          ? 'bg-blue-50/80 dark:bg-blue-950/40 border-blue-600 shadow-md shadow-blue-500/15 ring-2 ring-blue-500/20'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-white/5 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                          {preset.name}
                        </span>
                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">
                            ✓
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500">
                        Quarter {preset.quarter} · Target Date: {preset.defaultDate}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Target Exam Date */}
              <div className="pt-2">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Examination Target Date:
                </label>
                <input
                  type="date"
                  value={examDate}
                  onChange={e => setExamDate(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                />
              </div>
            </div>
          )}

          {/* STEP 3: VISUAL PDF UPLOAD & RECOGNITION */}
          {step === 'input' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                    Provide Portion Division for {effectiveShortName}
                  </h4>
                  <p className="text-xs text-slate-500">
                    Upload your school's official portion PDF or photo. The visual engine renders pages and recognizes tables without destroying column-row relationships.
                  </p>
                </div>

                <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1">
                  <button
                    type="button"
                    onClick={() => setInputMode('pdf')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      inputMode === 'pdf'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Visual PDF</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputMode('photo')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      inputMode === 'photo'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Photo</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputMode('paste')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      inputMode === 'paste'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Text Editor</span>
                  </button>
                </div>
              </div>

              {/* Processing Loader */}
              {isProcessingFile && (
                <div className="p-6 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 flex flex-col items-center justify-center gap-3 text-center animate-pulse">
                  <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <div>
                    <h5 className="text-sm font-extrabold text-blue-900 dark:text-blue-200">
                      Reading Document Visually
                    </h5>
                    <p className="text-xs text-blue-700 dark:text-blue-300 mt-0.5">
                      {processStatusMessage || 'Rendering pages to canvas and analyzing table structure…'}
                    </p>
                  </div>
                </div>
              )}

              {fileError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/40 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{fileError}</span>
                </div>
              )}

              {/* TAB 1: VISUAL PDF UPLOADER */}
              {inputMode === 'pdf' && !isProcessingFile && (
                <div className="flex flex-col gap-3">
                  <div
                    onClick={() => pdfInputRef.current?.click()}
                    className="p-8 rounded-3xl border-2 border-dashed border-blue-300 dark:border-blue-800/60 bg-blue-50/40 dark:bg-blue-950/20 hover:bg-blue-50/80 dark:hover:bg-blue-950/40 cursor-pointer flex flex-col items-center justify-center gap-3 text-center transition"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/25">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-sm font-extrabold text-slate-900 dark:text-white block">
                        Choose Portion Division PDF
                      </span>
                      <span className="text-xs text-slate-500 block mt-0.5">
                        High-resolution canvas rendering · Tables & columns recognized · Scans supported
                      </span>
                    </div>
                    <input
                      ref={pdfInputRef}
                      type="file"
                      accept="application/pdf,.pdf"
                      className="hidden"
                      onChange={e => {
                        const file = e.target.files?.[0];
                        if (file) handlePdfUpload(file);
                        e.target.value = '';
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 px-1">
                    <span>Includes visual OCR and spatial row-column alignment</span>
                    <button
                      type="button"
                      onClick={() => handleLoadSample(effectiveGrade, selectedExamId)}
                      className="font-bold text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Or load sample {effectiveGrade} portions →
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: PHOTO / SCAN UPLOADER */}
              {inputMode === 'photo' && !isProcessingFile && (
                <div className="flex flex-col gap-3">
                  <div
                    onClick={() => photoInputRef.current?.click()}
                    className="p-8 rounded-3xl border-2 border-dashed border-indigo-300 dark:border-indigo-800/60 bg-indigo-50/40 dark:bg-indigo-950/20 hover:bg-indigo-50/80 cursor-pointer flex flex-col items-center justify-center gap-3 text-center transition"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/25">
                      <Camera className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-sm font-extrabold text-slate-900 dark:text-white block">
                        Upload Photo of Printed or Handwritten Portion
                      </span>
                      <span className="text-xs text-slate-500 block mt-0.5">
                        Supports PNG, JPG, JPEG · Reads tables and handwritten notes
                      </span>
                    </div>
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={e => {
                        const file = e.target.files?.[0];
                        if (file) handlePhotoUpload(file);
                        e.target.value = '';
                      }}
                    />
                  </div>
                </div>
              )}

              {/* TAB 3: TEXT PASTE / DIRECT EDITOR */}
              {inputMode === 'paste' && (
                <div className="flex flex-col gap-3">
                  <textarea
                    rows={8}
                    value={portionText}
                    onChange={e => setPortionText(e.target.value)}
                    placeholder="Example:&#10;Mathematics: pages 81–170 (Polynomials)&#10;Physics: pages 59–116 (Newton's Laws)&#10;Chemistry: pages 60–105&#10;Biology: pages 51–95"
                    className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-mono font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
                  />
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => handleLoadSample(effectiveGrade, selectedExamId)}
                      className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      + Insert Sample {effectiveGrade} {effectiveShortName} Syllabus
                    </button>
                    <span className="text-[11px] text-slate-400">
                      {portionText.split('\n').filter(Boolean).length} lines entered
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: STRUCTURED VISUAL VERIFICATION PREVIEW TABLE (CRITICAL REQUIREMENT 4) */}
          {step === 'confirm' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* Extraction Header Summary */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/40 dark:to-indigo-950/40 border border-blue-200 dark:border-blue-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-extrabold text-blue-950 dark:text-blue-100">
                      {effectiveGrade} · {effectiveExamName}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-600 text-white">
                      {extractionMethod === 'multimodal_gemini' ? 'Multimodal AI Verified' : 'Spatial Table Analysis'}
                    </span>
                  </div>
                  <span className="text-slate-600 dark:text-slate-300 block mt-0.5">
                    Target Exam Date: <strong className="text-blue-700 dark:text-blue-300">{examDate}</strong> · Total Workload:{' '}
                    <strong className="text-blue-700 dark:text-blue-300">{totalPagesWorkload} pages across {extractedSubjects.length} subjects</strong>
                  </span>
                </div>

                {renderedPdfPages.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setInspectingSubject(extractedSubjects[0] || null)}
                    className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 shadow-2xs hover:bg-slate-50 transition shrink-0"
                    title="Open original document visual inspector"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600" />
                    <span>Inspect Original Document</span>
                  </button>
                )}
              </div>

              {/* Table Instructions */}
              <div className="flex items-center justify-between px-1">
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>Structured Portion Breakdown</span>
                    <span className="text-xs text-slate-500 font-medium">
                      (Tap any page range to inspect the original PDF page)
                    </span>
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddSubj(prev => !prev)}
                  className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Missing Subject</span>
                </button>
              </div>

              {/* Add Subject Drawer */}
              {showAddSubj && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white">
                    Add Subject to Portion Table
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                    <input
                      type="text"
                      placeholder="Examination (e.g. Test 2 or FQT)"
                      value={newSubExam}
                      onChange={e => setNewSubExam(e.target.value)}
                      className="h-9 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                    />
                    <input
                      type="text"
                      placeholder="Subject Name (e.g. Chemistry)"
                      value={newSubName}
                      onChange={e => setNewSubName(e.target.value)}
                      className="h-9 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                    />
                    <input
                      type="number"
                      placeholder="Start Page (e.g. 81)"
                      value={newSubStart}
                      onChange={e => setNewSubStart(e.target.value)}
                      className="h-9 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                    />
                    <input
                      type="number"
                      placeholder="End Page (e.g. 170)"
                      value={newSubEnd}
                      onChange={e => setNewSubEnd(e.target.value)}
                      className="h-9 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Topics / Chapters (e.g. Stoichiometry & Gas Laws)"
                    value={newSubTopics}
                    onChange={e => setNewSubTopics(e.target.value)}
                    className="w-full h-9 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddSubj(false)}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddNewSubject}
                      className="px-4 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold"
                    >
                      Add Row
                    </button>
                  </div>
                </div>
              )}

              {/* EXACT STRUCTURED VERIFICATION TABLE (Requirement 4) */}
              <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-white/10 shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 uppercase tracking-wider font-extrabold text-[10px]">
                    <tr>
                      <th className="py-3 px-3.5">Examination</th>
                      <th className="py-3 px-3.5">Subject</th>
                      <th className="py-3 px-3.5">Topics / Chapters</th>
                      <th className="py-3 px-3.5">Page Range</th>
                      <th className="py-3 px-3.5">Original Doc Ref</th>
                      <th className="py-3 px-3.5">Status</th>
                      <th className="py-3 px-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-white/5">
                    {extractedSubjects.map(s => {
                      const isEditing = editingSubjId === s.id;
                      const pageSpan = Math.max(1, s.endPage - s.startPage + 1);

                      return (
                        <tr
                          key={s.id}
                          className="hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition-colors"
                        >
                          {/* Examination Column */}
                          <td className="py-3 px-3.5 font-bold whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 text-[11px] font-extrabold">
                              {s.examName || effectiveShortName}
                            </span>
                          </td>

                          {/* Subject Column */}
                          <td className="py-3 px-3.5 font-extrabold text-slate-900 dark:text-white">
                            <div className="flex items-center gap-2">
                              <span>{s.emoji}</span>
                              {isEditing ? (
                                <input
                                  type="text"
                                  defaultValue={s.name}
                                  id={`edit-name-${s.id}`}
                                  className="h-7 px-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 font-bold text-xs"
                                />
                              ) : (
                                <span>{s.name}</span>
                              )}
                            </div>
                          </td>

                          {/* Topics Column */}
                          <td className="py-3 px-3.5 text-slate-600 dark:text-slate-300 max-w-xs">
                            {isEditing ? (
                              <input
                                type="text"
                                defaultValue={s.topics.join(', ')}
                                id={`edit-topics-${s.id}`}
                                className="h-7 px-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-xs w-full"
                              />
                            ) : (
                              <span className="truncate block" title={s.topics.join(', ')}>
                                {s.topics.length > 0 ? s.topics.join(', ') : '—'}
                              </span>
                            )}
                          </td>

                          {/* Page Range Column */}
                          <td className="py-3 px-3.5 whitespace-nowrap font-extrabold">
                            {isEditing ? (
                              <div className="flex items-center gap-1">
                                <input
                                  type="number"
                                  defaultValue={s.startPage}
                                  id={`edit-start-${s.id}`}
                                  className="w-14 h-7 px-1.5 rounded-lg text-center font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600"
                                />
                                <span className="text-slate-400">–</span>
                                <input
                                  type="number"
                                  defaultValue={s.endPage}
                                  id={`edit-end-${s.id}`}
                                  className="w-14 h-7 px-1.5 rounded-lg text-center font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600"
                                />
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  if (renderedPdfPages.length > 0) {
                                    setInspectingSubject(s);
                                  } else {
                                    setEditingSubjId(s.id);
                                  }
                                }}
                                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 dark:bg-slate-800 dark:hover:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-black transition flex items-center gap-1.5"
                                title="Tap to inspect original PDF page"
                              >
                                <span>pp. {s.startPage}–{s.endPage}</span>
                                <span className="text-[10px] text-slate-400 font-normal">({pageSpan}p)</span>
                              </button>
                            )}
                          </td>

                          {/* Original Document Reference Column & Tap to Inspect */}
                          <td className="py-3 px-3.5 whitespace-nowrap">
                            {renderedPdfPages.length > 0 ? (
                              <button
                                type="button"
                                onClick={() => setInspectingSubject(s)}
                                className="flex items-center gap-1 text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline"
                                title="Tap to see original PDF page"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>PDF Page {s.sourcePageNumber}</span>
                              </button>
                            ) : (
                              <span className="text-[11px] text-slate-400">Pasted Text</span>
                            )}
                          </td>

                          {/* Status / Confidence Column */}
                          <td className="py-3 px-3.5 whitespace-nowrap">
                            {s.confidence === 'high' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3" />
                                Verified ✓
                              </span>
                            ) : (
                              <span
                                className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full"
                                title={s.uncertaintyReason || 'Please verify against document'}
                              >
                                <AlertCircle className="w-3 h-3" />
                                Review ⚠️
                              </span>
                            )}
                          </td>

                          {/* Actions Column */}
                          <td className="py-3 px-3.5 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              {isEditing ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nameEl = document.getElementById(`edit-name-${s.id}`) as HTMLInputElement;
                                    const startEl = document.getElementById(`edit-start-${s.id}`) as HTMLInputElement;
                                    const endEl = document.getElementById(`edit-end-${s.id}`) as HTMLInputElement;
                                    const topicsEl = document.getElementById(`edit-topics-${s.id}`) as HTMLInputElement;

                                    const start = parseInt(startEl?.value, 10) || s.startPage;
                                    const end = Math.max(start, parseInt(endEl?.value, 10) || s.endPage);
                                    const name = nameEl?.value.trim() || s.name;
                                    const topics = topicsEl?.value
                                      ? topicsEl.value.split(',').map(t => t.trim()).filter(Boolean)
                                      : s.topics;

                                    handleUpdateSubject(s.id, {
                                      name,
                                      startPage: start,
                                      endPage: end,
                                      topics
                                    });
                                    setEditingSubjId(null);
                                  }}
                                  className="p-1 rounded-md bg-emerald-600 text-white"
                                  title="Save edits"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => setEditingSubjId(s.id)}
                                    className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                    title="Edit subject row"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteSubject(s.id)}
                                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                    title="Remove row"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Unrecognized sections warning if any */}
              {unrecognizedLines.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 text-xs">
                  <span className="font-extrabold text-amber-900 dark:text-amber-200 block mb-1">
                    Unrecognized or Extra Notes from Document ({unrecognizedLines.length}):
                  </span>
                  <div className="space-y-1 text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                    {unrecognizedLines.slice(0, 4).map((line, idx) => (
                      <div key={idx} className="truncate">• {line}</div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Bottom Footer Navigation */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
          <div>
            {step === 'grade' && (
              <span className="text-xs text-slate-500 font-medium">Step 1 of 4: Grade Level</span>
            )}
            {step === 'exam' && (
              <button
                type="button"
                onClick={() => setStep('grade')}
                className="px-3.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}
            {step === 'input' && (
              <button
                type="button"
                onClick={() => setStep('exam')}
                className="px-3.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}
            {step === 'confirm' && (
              <button
                type="button"
                onClick={() => setStep('input')}
                className="px-3.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Upload</span>
              </button>
            )}
          </div>

          <div>
            {step === 'grade' && (
              <button
                type="button"
                onClick={() => setStep('exam')}
                className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-500/20"
              >
                <span>Next: Choose Examination</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 'exam' && (
              <button
                type="button"
                onClick={() => setStep('input')}
                className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-500/20"
              >
                <span>Next: Upload / Enter Portions</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 'input' && (
              <button
                type="button"
                onClick={handleParseTextAndReview}
                className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-500/20"
              >
                <span>Review Structured Preview</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {step === 'confirm' && (
              <button
                type="button"
                onClick={handleFinalBuild}
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-blue-500/30"
              >
                <Sparkles className="w-4 h-4" />
                <span>Confirm & Apply Portions to {effectiveShortName}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Visual PDF Page Inspector Modal */}
      {inspectingSubject && (
        <VisualPdfInspectorModal
          pages={renderedPdfPages}
          initialSubject={inspectingSubject}
          onClose={() => setInspectingSubject(null)}
        />
      )}
    </div>
  );
};
