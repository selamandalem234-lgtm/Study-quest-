import React, { useState } from 'react';
import { RenderedPdfPage, VisualExtractedSubject } from '../visualPortionEngine.ts';
import { X, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, Eye, ShieldCheck, AlertCircle } from 'lucide-react';

interface VisualPdfInspectorModalProps {
  pages: RenderedPdfPage[];
  initialSubject?: VisualExtractedSubject | null;
  onClose: () => void;
}

export const VisualPdfInspectorModal: React.FC<VisualPdfInspectorModalProps> = ({
  pages,
  initialSubject,
  onClose
}) => {
  const initialPageIdx = initialSubject
    ? Math.max(0, Math.min(pages.length - 1, initialSubject.sourcePageNumber - 1))
    : 0;

  const [currentPageIdx, setCurrentPageIdx] = useState<number>(initialPageIdx);
  const [zoom, setZoom] = useState<number>(1);

  if (!pages || pages.length === 0) {
    return null;
  }

  const curPage = pages[currentPageIdx] || pages[0];
  const box = initialSubject && initialSubject.sourcePageNumber === curPage.pageNumber
    ? initialSubject.sourceBox
    : undefined;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-4xl h-[92vh] max-h-[900px] rounded-3xl bg-slate-900 border border-white/10 flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header Bar */}
        <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between gap-3 bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold text-sm">
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <span>Original PDF Visual Inspector</span>
                {initialSubject && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-blue-600/30 text-blue-300 font-bold">
                    {initialSubject.name}: pp {initialSubject.startPage}–{initialSubject.endPage}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-400">
                Verifying visual layout directly against your original uploaded document
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Zoom Controls */}
            <div className="flex items-center bg-slate-800 rounded-xl p-1 border border-white/5">
              <button
                type="button"
                onClick={() => setZoom(z => Math.max(0.6, z - 0.2))}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 transition"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-bold text-slate-300 px-2 min-w-[42px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoom(z => Math.min(2.5, z + 0.2))}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 transition"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Page Navigation */}
            <div className="flex items-center bg-slate-800 rounded-xl p-1 border border-white/5">
              <button
                type="button"
                disabled={currentPageIdx <= 0}
                onClick={() => setCurrentPageIdx(p => Math.max(0, p - 1))}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 transition"
                title="Previous Page"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-bold text-slate-300 px-2 whitespace-nowrap">
                Page {currentPageIdx + 1} of {pages.length}
              </span>
              <button
                type="button"
                disabled={currentPageIdx >= pages.length - 1}
                onClick={() => setCurrentPageIdx(p => Math.min(pages.length - 1, p + 1))}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 transition"
                title="Next Page"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
              title="Close Inspector"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Highlight Banner if Subject Selected */}
        {initialSubject && (
          <div className="px-5 py-2 bg-blue-950/40 border-b border-blue-900/40 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-blue-200">
              <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
              <span>
                Target Subject: <strong className="text-white">{initialSubject.name}</strong> · Examination:{' '}
                <strong className="text-white">{initialSubject.examName}</strong> · Extracted Range:{' '}
                <strong className="text-amber-300">pages {initialSubject.startPage} to {initialSubject.endPage}</strong>
              </span>
            </div>
            {initialSubject.confidence === 'uncertain' && (
              <span className="flex items-center gap-1 text-amber-300 font-bold bg-amber-950/60 px-2 py-0.5 rounded-lg">
                <AlertCircle className="w-3.5 h-3.5" />
                Uncertain: Please verify
              </span>
            )}
          </div>
        )}

        {/* Scrollable Visual Canvas Viewport */}
        <div className="flex-1 overflow-auto bg-slate-950 p-4 sm:p-6 flex items-center justify-center">
          <div
            className="relative transition-transform duration-100 ease-out shadow-2xl rounded-lg overflow-hidden border border-white/10"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: 'center center'
            }}
          >
            {/* Rendered PDF Page Image */}
            <img
              src={curPage.imageDataUrl}
              alt={`PDF Page ${curPage.pageNumber}`}
              className="max-w-none block bg-white"
              style={{ width: curPage.width, height: curPage.height }}
            />

            {/* Glowing Visual Bounding Box around Detected Row */}
            {box && initialSubject && (
              <div
                className="absolute border-2 border-blue-500 bg-blue-500/20 rounded shadow-[0_0_15px_rgba(59,130,246,0.6)] pointer-events-none animate-pulse"
                style={{
                  left: box.x,
                  top: box.y,
                  width: Math.max(80, box.width),
                  height: Math.max(24, box.height)
                }}
              >
                <div className="absolute -top-6 left-0 px-2 py-0.5 rounded bg-blue-600 text-[10px] font-black text-white whitespace-nowrap shadow-md">
                  {initialSubject.name}: pp {initialSubject.startPage}–{initialSubject.endPage}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Helper Bar */}
        <div className="px-5 py-2.5 bg-slate-950/80 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span>Tapping any subject in the table reveals its original row in this document.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
          >
            Done Viewing
          </button>
        </div>
      </div>
    </div>
  );
};
