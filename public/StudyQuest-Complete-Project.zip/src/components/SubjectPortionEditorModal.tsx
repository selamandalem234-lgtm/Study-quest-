import React, { useState } from 'react';
import { Subject, StudyPortion } from '../types.ts';
import { X, BookOpen, Trash2, Plus, Check, Sparkles, Layers } from 'lucide-react';

interface SubjectPortionEditorModalProps {
  subject: Subject;
  examIndex: number;
  examName?: string;
  onSave: (updated: Subject) => void;
  onDelete: (subjectName: string) => void;
  onClose: () => void;
}

export const SubjectPortionEditorModal: React.FC<SubjectPortionEditorModalProps> = ({
  subject,
  examIndex,
  examName,
  onSave,
  onDelete,
  onClose
}) => {
  const [name, setName] = useState(subject.name);
  const [emoji, setEmoji] = useState(subject.emoji);
  const currentRange = subject.ranges?.[0] || [1, 50];
  const [startPage, setStartPage] = useState(String(currentRange[0]));
  const [endPage, setEndPage] = useState(String(currentRange[1]));
  const [portions, setPortions] = useState<StudyPortion[]>(
    subject.portions || [
      {
        id: `p-1`,
        title: 'Full Portion',
        startPage: currentRange[0],
        endPage: currentRange[1]
      }
    ]
  );
  const [showAddPortion, setShowAddPortion] = useState(false);
  const [newPortionTitle, setNewPortionTitle] = useState('');
  const [newPortionStart, setNewPortionStart] = useState('');
  const [newPortionEnd, setNewPortionEnd] = useState('');

  const handleAddPortion = () => {
    if (!newPortionTitle.trim()) return;
    const s = parseInt(newPortionStart, 10) || 1;
    const e = Math.max(s, parseInt(newPortionEnd, 10) || s + 10);
    const newP: StudyPortion = {
      id: `portion-${Date.now()}`,
      title: newPortionTitle.trim(),
      startPage: s,
      endPage: e
    };
    setPortions(prev => [...prev, newP]);
    setNewPortionTitle('');
    setNewPortionStart('');
    setNewPortionEnd('');
    setShowAddPortion(false);
  };

  const handleDeletePortion = (id: string) => {
    setPortions(prev => prev.filter(p => p.id !== id));
  };

  const handleSave = () => {
    const s = parseInt(startPage, 10) || 1;
    const e = Math.max(s, parseInt(endPage, 10) || s + 10);
    const newRanges: [number, number][] = [[s, e]];

    const updated: Subject = {
      ...subject,
      name: name.trim() || subject.name,
      emoji: emoji || subject.emoji,
      ranges: newRanges,
      portions
    };

    onSave(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{emoji}</span>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Edit Subject &amp; Portions
              </h3>
              <p className="text-xs text-slate-500">
                Update study scope, chapters, and textbook pages.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="py-4 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Name & Emoji */}
          <div className="grid grid-cols-4 gap-3">
            <div className="col-span-1">
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">
                Emoji
              </label>
              <input
                type="text"
                value={emoji}
                onChange={e => setEmoji(e.target.value)}
                className="w-full h-11 text-center text-xl rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              />
            </div>
            <div className="col-span-3">
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">
                Subject Name
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Active Page Range for Current Exam */}
          <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Textbook Page Range for {examName || 'Active Exam'}</span>
              </label>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <span className="text-[10px] text-slate-500">Start Page</span>
                <input
                  type="number"
                  value={startPage}
                  onChange={e => setStartPage(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
              <span className="text-slate-400 pt-3 font-bold">–</span>
              <div className="flex-1">
                <span className="text-[10px] text-slate-500">End Page</span>
                <input
                  type="number"
                  value={endPage}
                  onChange={e => setEndPage(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Chapters & Smaller Study Portions */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-500" />
                <span>Chapters &amp; Sub-Portions</span>
              </label>
              <button
                type="button"
                onClick={() => setShowAddPortion(!showAddPortion)}
                className="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Add Chapter
              </button>
            </div>

            {showAddPortion && (
              <div className="p-3 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/40 space-y-2">
                <input
                  type="text"
                  placeholder="Chapter/Unit title (e.g. Unit 3: Optics)"
                  value={newPortionTitle}
                  onChange={e => setNewPortionTitle(e.target.value)}
                  className="w-full h-8 px-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    placeholder="Start p."
                    value={newPortionStart}
                    onChange={e => setNewPortionStart(e.target.value)}
                    className="w-20 h-8 px-2 text-center rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                  <span>–</span>
                  <input
                    type="number"
                    placeholder="End p."
                    value={newPortionEnd}
                    onChange={e => setNewPortionEnd(e.target.value)}
                    className="w-20 h-8 px-2 text-center rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                  <div className="flex-1 flex justify-end gap-1">
                    <button
                      type="button"
                      onClick={() => setShowAddPortion(false)}
                      className="px-2 py-1 text-xs text-slate-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddPortion}
                      className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {portions.map(p => (
                <div
                  key={p.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-xs"
                >
                  <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                    {p.title}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] text-slate-500">
                      pp. {p.startPage}–{p.endPage}
                    </span>
                    <button
                      onClick={() => handleDeletePortion(p.id)}
                      className="text-slate-400 hover:text-rose-500 p-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              if (confirm(`Delete ${subject.name} from your study quest?`)) {
                onDelete(subject.name);
                onClose();
              }
            }}
            className="flex items-center gap-1 text-xs font-bold text-rose-500 hover:text-rose-600 px-3 py-2 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Subject</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
